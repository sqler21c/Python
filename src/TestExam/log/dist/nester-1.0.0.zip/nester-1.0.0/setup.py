
'''
Created on 2015. 11. 2.

@author: User
'''
from distutils.core import setup

setup(
      name = 'nester',
      version = '1.0.0',
      py_modules = ['nester'],
      author = 'sun',
      author_email = 'sudnt@nager.com',
      url='http;//dlld.com',
      decription = 'a firt package',
      )